package com.example.dvisn_app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class General_Input extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_general_input);
    }
}