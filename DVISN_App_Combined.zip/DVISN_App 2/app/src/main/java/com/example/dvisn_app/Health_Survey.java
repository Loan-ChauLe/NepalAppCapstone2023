package com.example.dvisn_app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class Health_Survey extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_health_survey);
        configureBackButton();
    }
    private void configureBackButton() {
        ImageButton backButton = (ImageButton) findViewById(R.id.GoBack);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // here, don't use the start activity button to go back
                // use finish so that using the built-in android back button will work
                finish();
                // if going to another different activity, then use StartActivity
            }
        });
    }
}