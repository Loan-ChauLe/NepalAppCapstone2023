package com.example.dvisn_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        configureNextButton();
    }
    private void configureNextButton() {
        Button genInputButton = (Button) findViewById(R.id.input_button);
        genInputButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // to move to a different activity, need to call startActivity method
                // then new Intent([startingActivity.this], [nextActivity.class])
                startActivity(new Intent(MainActivity.this, General_Input.class));
            }
        });
    }
}