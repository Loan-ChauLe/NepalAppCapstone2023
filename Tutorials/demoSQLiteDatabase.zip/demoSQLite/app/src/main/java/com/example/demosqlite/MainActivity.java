package com.example.demosqlite;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    //creating an instance of the class/ declaring the class
    DatabaseHelper myDb;
    // can declare multiple variables of the same datatype on one line
    EditText inputName, inputSurname, inputMarks;
    Button addDataBtn, viewAllBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // calling the code to create database and table
        myDb = new DatabaseHelper(this);
        inputName = (EditText) findViewById(R.id.inputName);
        inputSurname = (EditText) findViewById(R.id.inputSurname);
        inputMarks = (EditText) findViewById(R.id.inputMarks);
        addDataBtn = (Button) findViewById(R.id.addButton);
        viewAllBtn = (Button) findViewById(R.id.viewAllButton);

        // call AddData method
        AddData();
        viewAll();
    }

    public void AddData() {
        // connect to when button is clicked
        addDataBtn.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        // now in here, call the insertData method we wrote
                        // class_name.insertData(arguments)
                        boolean isInserted = myDb.insertData(inputName.getText().toString(),
                                inputSurname.getText().toString(),
                                inputMarks.getText().toString() );
                        if(isInserted)
                            // puts a lil fading message on app screen
                            Toast.makeText(MainActivity.this, "Data Inserted",
                                    Toast.LENGTH_LONG).show();
                        else
                            Toast.makeText(MainActivity.this, "Data not Inserted",
                                    Toast.LENGTH_LONG).show();
                    }
                }
        );
    }

    public void viewAll() {
        viewAllBtn.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Cursor results = myDb.getAllData();
                        if(results.getCount() == 0) {
                            // show error message
                            showMessage("Error", "No data found");
                            return;
                        }

                        StringBuffer buffer = new StringBuffer();
                        // moveToNext moves the cursor to the next result
                        while (results.moveToNext()) {
                            buffer.append("ID: " + results.getString(0) + "\n");
                            buffer.append("Name: " + results.getString(1) + "\n");
                            buffer.append("Surname: " + results.getString(2) + "\n");
                            buffer.append("Marks: " + results.getString(3) + "\n\n");
                        }

                        // Show all data
                        showMessage("Data", buffer.toString());
                    }
                }
        );
    }

    public void showMessage(String title, String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}