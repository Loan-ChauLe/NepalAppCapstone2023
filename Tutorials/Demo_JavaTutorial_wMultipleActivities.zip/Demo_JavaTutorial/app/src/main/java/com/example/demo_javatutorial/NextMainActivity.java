package com.example.demo_javatutorial;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class NextMainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_next_main);

        configureBackButton();
    }

    private void configureBackButton() {
        ImageButton backButton = (ImageButton) findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // here, don't use the start activity button to go back
                // use finish so that using the built-in android back button will work
                finish();
                // if going to another different activity, then use StartActivity
            }
        });
    }
}