package com.example.demo_javatutorial;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    //declare layout elements (also have to import the widgets used)
    // can declare and connect at the same time on the same line
    Button buttonA;
    Button buttonB;
    Button buttonC;
    TextView topText;
    EditText inputText1;
    Button nameButton;

    // connect the declared variable names to the elements on the layout
    // inside the protected void onCreate
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // variable name = (widgetType) findViewById(R.id.widgetID);
        buttonA = (Button) findViewById(R.id.testButton);
        buttonB = (Button) findViewById(R.id.testButton2);
        buttonC = (Button) findViewById(R.id.testButton3);
        topText = (TextView) findViewById(R.id.txt);
        inputText1 = (EditText) findViewById(R.id.inputText);
        nameButton = (Button) findViewById(R.id.submitBtn);

        // set on click listener to detect if/when user clicks on buttons
        buttonA.setOnClickListener(this);
        buttonB.setOnClickListener(this);
        buttonC.setOnClickListener(this);
        nameButton.setOnClickListener(this);

        // to switch to a different activity
        configureNextButton();
    }

    // start a new method with ctrl + I
    // whenever the user clicks on any of the buttons, this method will be executed
    @Override
    public void onClick(View view) {
        // to specify buttonA, get the ID of the button clicked by user and then check if the
        // ID is the ID of buttonA
        if(view.getId()==R.id.testButton){
            topText.setText("A is clicked");
        }
        if(view.getId()==R.id.testButton2){
            topText.setText("B is clicked");
        }
        if(view.getId()==R.id.testButton3){
            topText.setText("C is clicked");
        }
        if(view.getId()==R.id.submitBtn){
            topText.setText("Hi, " + inputText1.getText());
        }
    }

    private void configureNextButton() {
        Button nextButton = (Button) findViewById(R.id.nextPageBtn);
        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // to move to a different activity, need to call startActivity method
                // then new Intent([startingActivity.this], [nextActivity.class])
                startActivity(new Intent(MainActivity.this, NextMainActivity.class));
            }
        });
    }
}