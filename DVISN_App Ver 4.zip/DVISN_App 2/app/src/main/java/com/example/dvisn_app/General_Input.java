package com.example.dvisn_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class General_Input extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_general_input);
        configureHealthButton();
    }
    private void configureHealthButton() {
        Button HealthInputButton = (Button) findViewById(R.id.health_input);
        HealthInputButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // to move to a different activity, need to call startActivity method
                // then new Intent([startingActivity.this], [nextActivity.class])
                startActivity(new Intent(General_Input.this, Health_Survey.class));
            }
        });
    }
}