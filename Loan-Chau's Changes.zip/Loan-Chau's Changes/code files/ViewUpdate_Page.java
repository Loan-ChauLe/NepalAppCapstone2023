package com.example.dvisn_app;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class ViewUpdate_Page extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_update_page);

        configureBackButton();
    }

    private void configureBackButton() {
        ImageButton backButton = (ImageButton) findViewById(R.id.view_update_BackButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // here, don't use the start activity button to go back
                // use finish so that using the built-in android back button will work
                finish();
                // if going to another different activity, then use StartActivity
            }
        });
    }
}