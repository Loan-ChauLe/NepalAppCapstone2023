package com.example.dvisn_app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class Search_Page extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_page);

        configureBackButton();
        configureExStudentButton();

        // drop down menu for provinces
        Spinner spinnerProvinces=findViewById(R.id.spinner_Provinces);
        ArrayAdapter<CharSequence>adapter=ArrayAdapter.createFromResource(this, R.array.provinces, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        spinnerProvinces.setAdapter(adapter);
    }

    private void configureBackButton() {
        ImageButton backButton = (ImageButton) findViewById(R.id.search_BackButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // here, don't use the start activity button to go back
                // use finish so that using the built-in android back button will work
                finish();
                // if going to another different activity, then use StartActivity
            }
        });
    }

    private void configureExStudentButton() {
        // for the example student profile Buttons on Search page
        Button Student1Button = (Button) findViewById(R.id.ex_student1Button);
        Button Student2Button = (Button) findViewById(R.id.ex_student2Button);
        Student1Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // to move to a different activity, need to call startActivity method
                // then new Intent([startingActivity.this], [nextActivity.class])
                startActivity(new Intent(Search_Page.this, ViewUpdate_Page.class));
            }
        });
        Student2Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // to move to a different activity, need to call startActivity method
                // then new Intent([startingActivity.this], [nextActivity.class])
                startActivity(new Intent(Search_Page.this, ViewUpdate_Page.class));
            }
        });
    }
}
