package com.example.dvisn_app;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

public class Education_Survey extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_education_survey);
        configureBackButton();

        // Spinner 1
        Spinner mySpinner = (Spinner) findViewById(R.id.spinner1);

        ArrayAdapter<String> myAdapter = new ArrayAdapter<String>(Education_Survey.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.names));
        myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mySpinner.setAdapter(myAdapter);

        // Spinner 2
        Spinner mySpinner2 = (Spinner) findViewById(R.id.spinner2);

        ArrayAdapter<String> myAdapter2 = new ArrayAdapter<String>(Education_Survey.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.names));
        myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mySpinner2.setAdapter(myAdapter2);

        // Spinner 3
        Spinner mySpinner3 = (Spinner) findViewById(R.id.spinner3);

        ArrayAdapter<String> myAdapter3 = new ArrayAdapter<String>(Education_Survey.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.names));
        myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mySpinner3.setAdapter(myAdapter3);

        // Spinner 4
        Spinner mySpinner4 = (Spinner) findViewById(R.id.spinner4);

        ArrayAdapter<String> myAdapter4 = new ArrayAdapter<String>(Education_Survey.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.options));
        myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mySpinner4.setAdapter(myAdapter4);

        // Spinner 5
        Spinner mySpinner5 = (Spinner) findViewById(R.id.spinner5);

        ArrayAdapter<String> myAdapter5 = new ArrayAdapter<String>(Education_Survey.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.options));
        myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mySpinner5.setAdapter(myAdapter5);
    }
    private void configureBackButton() {
        ImageButton backButton = (ImageButton) findViewById(R.id.Ed_GoBack);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // here, don't use the start activity button to go back
                // use finish so that using the built-in android back button will work
                finish();
                // if going to another different activity, then use StartActivity
            }
        });
    }
}
